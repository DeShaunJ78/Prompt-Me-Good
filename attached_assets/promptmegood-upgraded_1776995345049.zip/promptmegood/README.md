# PromptMeGood MVP - Upgraded Version

PromptMeGood turns vague ideas into stronger AI prompts that can be copied into ChatGPT, Claude, Perplexity, Gemini, or similar tools.

## What was upgraded

- Stronger homepage copy focused on outcomes.
- Added optional extra details field for context, budget, timeline, platform, and constraints.
- Added Money Mode toggle to push prompts toward income, speed, and practical execution.
- Improved prompt-generation logic with clearer structure, assumptions, warnings, examples, and next actions.
- Added upgrade buttons:
  - Make more detailed
  - Make more aggressive
  - Make beginner-friendly
- Added use-case cards for money, dropshipping, content, and faith.
- Updated demo values to match the first target audience: people trying to make money with AI prompts.

## File structure

```bash
promptmegood/
├── promptmegood.html
├── package.json
├── vercel.json
└── README.md
```

## Run locally

Open `promptmegood.html` in a browser.

Or run:

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Create a GitHub repository.
2. Upload these files into the repository.
3. Sign in to Vercel.
4. Click Add New Project.
5. Import the repository.
6. Keep framework preset as Other.
7. Deploy.

The `vercel.json` file sends the homepage to `promptmegood.html`.
